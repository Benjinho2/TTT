<!DOCTYPE html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <link rel="shortcut icon" href="../img/tasita.png">

    <title>Login</title>
  </head>
<body>
    <section>
      <div class="container mt-5 pt-5">
        <div class="row">
          <div class="col-12 col-sm-7 col-md-6 m-auto">
            <div class="card border-0 shadow">
              <div class="card-body">
                <svg class="mx-auto my-4 d-block" xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
                  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                </svg>
                  <h4 class="mx-auto d-block">Login</h4><hr>

                  <form action="<?= base_url('autenticacion/controlar'); ?>" method="post">
                      <?= csrf_field(); ?>
                      <?php if(!empty(session()->getFlashdata('fail'))) : ?>
                      <div class="alert alert-danger"><?= session()->getFlashdata('fail'); ?></div>
                      <?php endif ?>

                      <div class="cold-md-6">
                      <label for="">Email</label>
                        <div class="input-group">
                            <span class="input-group-text" id="basic-addon1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-at" viewBox="0 0 16 16">
                                  <path d="M2 2a2 2 0 0 0-2 2v8.01A2 2 0 0 0 2 14h5.5a.5.5 0 0 0 0-1H2a1 1 0 0 1-.966-.741l5.64-3.471L8 9.583l7-4.2V8.5a.5.5 0 0 0 1 0V4a2 2 0 0 0-2-2H2Zm3.708 6.208L1 11.105V5.383l4.708 2.825ZM1 4.217V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v.217l-7 4.2-7-4.2Z"/>
                                  <path d="M14.247 14.269c1.01 0 1.587-.857 1.587-2.025v-.21C15.834 10.43 14.64 9 12.52 9h-.035C10.42 9 9 10.36 9 12.432v.214C9 14.82 10.438 16 12.358 16h.044c.594 0 1.018-.074 1.237-.175v-.73c-.245.11-.673.18-1.18.18h-.044c-1.334 0-2.571-.788-2.571-2.655v-.157c0-1.657 1.058-2.724 2.64-2.724h.04c1.535 0 2.484 1.05 2.484 2.326v.118c0 .975-.324 1.39-.639 1.39-.232 0-.41-.148-.41-.42v-2.19h-.906v.569h-.03c-.084-.298-.368-.63-.954-.63-.778 0-1.259.555-1.259 1.4v.528c0 .892.49 1.434 1.26 1.434.471 0 .896-.227 1.014-.643h.043c.118.42.617.648 1.12.648Zm-2.453-1.588v-.227c0-.546.227-.791.573-.791.297 0 .572.192.572.708v.367c0 .573-.253.744-.564.744-.354 0-.581-.215-.581-.8Z"/>
                                </svg>
                            </span>
                            <input type="text" class="form-control" name="email" placeholder="Ingrese su Email" aria-label="Input group example" aria-describedy="basic-addon1" value="<?= set_value('email'); ?>">
                        </div>
                        <span class="text-danger"><?= isset($validation) ? $validation->getError('email') : '' ?></span>
                      </div>
                    
                      <div class="cold-md-6">
                      <label for="">Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text" id="basic-addon1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                              <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/>
                            </svg>
                            </span>
                            <input type="password" class="form-control" name="contraseña" placeholder="Ingrese su Contraseña" aria-label="Input group example" aria-describedy="basic-addon1" value="<?= set_value('contraseña'); ?>">
                        </div>
                        <span class="text-danger"><?= isset($validation) ? $validation->getError('contraseña') : '' ?></span>
                      </div>

                      <div class="mt-2">
                        <button class="btn btn-primary">Login</button>
                      </div>

                      <a href="<?= site_url('autenticacion/register'); ?>" class="nav-link py-2">¿No tienes una cuenta? Aquí</a>
                      <a href="<?= site_url(''); ?>" class="nav-link py-1 d-block">Inicio</a>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
  <script src="<?= base_url('js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
