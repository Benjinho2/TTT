tesina-ITR3

Está página permitirá a los usuarios seleccionar y reservar mesas de acuerdo con la disponibilidad horaria y fechas específicas a decisión del Usuario.

La plataforma proporcionará una interfaz de usuario intuitiva que mostrará los diversos tipos de menús disponibles. Esto incluirá opciones detalladas para el almuerzo, la merienda y la cena, con descripciones de platos, precios y fotografías de los alimentos para ayudar a los usuarios a tomar decisiones informadas sobre su elección gastronómica.
